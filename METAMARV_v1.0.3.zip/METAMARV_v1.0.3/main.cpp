/*************************************************************************
 METAMARV software:  Sep, 2016

 Contributors:
 * Marika Kaakinen
 * Reedik Mägi
 * Krista Fischer
 * Andrew P Morris
 * Inga Prokopenko

Copyright (c) 2015, Imperial College London
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*************************************************************************/

#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <fstream>
#include <stdlib.h>
#include <cctype> // std::toupper
#include <map>
#include <zlib.h>
#include "CmdLine.h"
#include "global.h"
#include "tools.h"
#include "structures.h"
#include "regression.h"
#include "studenttdistr.h"
#include "chisquaredistr.h"
#include "statistics.h"

#define LENS 1000000
using namespace TCLAP;
using namespace std;

bool readInput(global & G);

double abs_d(double x);

double
abs_d(double x)
{
    if (x < 0) return x * -1;
    return x;

}

int main (int argc, char * argv[])
{

    global GLOBAL;

    try
    {
        CmdLine cmd("For more info: http://www.geenivaramu.ee/en/tools/gmpa", ' ', GLOBAL.version );
        ValueArg<string> inFileArg("i","input","This specifies input file",true,"","string", cmd);
        ValueArg<string> outFileArg("o","out","This specifies output file",true,"","string", cmd);

        ValueArg<int> nArg("n","samplesize","This specifies samplesize filter",false,0,"int", cmd);

        SwitchArg debugArg("", "debug","Debug mode enabled", cmd);
        cmd.parse(argc,argv);
        GLOBAL.inFile = inFileArg.getValue();
        GLOBAL.outFile = outFileArg.getValue();
        GLOBAL.debugMode = debugArg.getValue();

        GLOBAL.nFilter = nArg.getValue();
        cout << "METAMARV version " << GLOBAL.version << endl;
        readInput(GLOBAL);
        ofstream OUT (GLOBAL.outFile.c_str());

        OUT << "Gene\tCohortCount\tN\tChiSq\tPvalue\n";


        for (int m=0;m<GLOBAL.markerList.size();m++)
        {
            matrixD V((unsigned)GLOBAL.phenoList.size(),(unsigned)GLOBAL.phenoList.size());
            for (int i=0; i<GLOBAL.phenoList.size();i++)
            {
                for (int j=i; j<GLOBAL.phenoList.size();j++)
                {
                    V.put(i,j,GLOBAL.markerList[m].getVjk(i, j));
                    V.put(j,i,GLOBAL.markerList[m].getVjk(i, j));
                }
            }
            V.InvertS();

            double chi = 0;
            arrayD Bj((unsigned)GLOBAL.phenoList.size());
            for (int i=0; i<GLOBAL.phenoList.size();i++)
            {
                for (int j=0; j<GLOBAL.phenoList.size();j++)
                {
                    double x1 = Bj.get(i);
                    double x2 = V.get(i,j);
                    double x3 = GLOBAL.markerList[m].getSj(j);

                    Bj.put(i,x1+(x2*x3));
                }
            }
            V.InvertS();
            for (int i=0; i<GLOBAL.phenoList.size();i++)
            {
                for (int j=0; j<GLOBAL.phenoList.size();j++)
                {
                    double x1 = V.get(i,j);
                    double x2 = Bj.get(i);
                    double x3 = Bj.get(j);
                    chi+=x1*x2*x3;
                }
            }
            if (chi<0){chi=chi*-1;}
            double pModel = 1-chisquaredistribution(GLOBAL.phenoList.size(),chi);
            OUT << GLOBAL.markerList[m]._name <<"\t" <<GLOBAL.markerList[m]._cohortCount<<"\t" << GLOBAL.markerList[m]._sampleCount <<"\t"<<chi<<"\t"<<pModel<<endl;
        }



  //               C.print();

 //               cout<<markerName << " " << betas[0]<<endl;







    } catch (ArgException &e)  // catch any exceptions
    { cerr << "error: " << e.error() << " for arg " << e.argId() << endl; }

    return 0;
}


bool readInput(global & G)
{

    ifstream I (G.inFile.c_str());
    int fileNr=0;
    int currentPosition=1;
    if (I.is_open())
    {
        int lineNr = 0;

       	while (! I.eof() )
        {
	        string line;
        	vector<string> tokens;
        	getline (I,line);
			string currentmarker = "";
			int n = Tokenize(string(line), tokens, " ");		//tabulating file by space
			if (n==1)
			{
                string myFile = string(tokens[0]);
                gzFile F = gzopen(myFile.c_str(),"r");
                cout << "Reading file " << myFile << endl;

                if (!F) {
                    cerr << "Reading file " << myFile << "failed. Exit program." << endl;
                    exit (EXIT_FAILURE);
                }
                lineNr = 0;
                map <string, int> markerNoDuplicate;
                int markerNoDupCount = 0;
                int markerDupCount=0;
                int markerbadNCount=0;
                int markerbadPCount=0;


                char *buffer = new char[LENS];
                map <string, bool> markerPresent;
                bool phenosNeedReordering = false; //current input file has phenotypes in different order
                vector<string> tokens3; //input file phenotype order
                while(0!=gzgets(F,buffer,LENS))
                {

                    string line2;
                    vector<string> tokens2; //input file columns




                    int n = Tokenize(buffer, tokens2, " ");            //tabulating file by space
                    if (n>2 && lineNr>0)
                    {

                            //read phenos
                        if (lineNr==1 && fileNr==0)
                        {
                            Tokenize(tokens2[14],G.phenoList,"+");
                            if (G.phenoList.size()<=1)
                            {
                                cerr << "Not enough phenotypes in file: " << myFile << endl;
                                exit(1);
                            }
                        }
                        else if(lineNr==1 && fileNr!=0)
                        {
                            //reading new file and must check if phenotypes are in the same order

                            Tokenize(tokens2[14],tokens3,"+");
                            if (G.phenoList.size() != tokens3.size())
                            {
                                cerr << "Non-matching pheno count in file: " << myFile << endl;
                                exit(1);
                            }
                            for (int i = 0; i<tokens3.size();i++)
                            {
                                if (tokens3[i] != G.phenoList[i])
                                {
                                    phenosNeedReordering=true;

                                }
                            }
                            if (phenosNeedReordering)cerr << "Reordering phenotypes" << endl;

                        }
                        if (lineNr>0 && G.nFilter<=atoi(tokens2[2].c_str()) &&
                            tokens2[10]!="NA"
                            && markerNoDuplicate[tokens2[0]]!=1)
                        {
                            string currentMarker = tokens2[0];
                            markerNoDuplicate[tokens2[0]]=1;
                            markerNoDupCount++;
                            double sampleSize = atof(tokens2[2].c_str());

                            bool markerIsOK = true;

                            if (markerPresent[currentMarker]==0)
                            {
                                if (G.markerPosition[currentMarker]==0)
                                {
                                //new marker
                                    G.markerPosition[currentMarker]=currentPosition;

                                    int position = currentPosition-1; //positions start with 1, vector starts with 0
                                    currentPosition++;
                                    G.markerList.push_back(Marker(currentMarker,(unsigned) G.phenoList.size()));



                                    int k = 0;
                                    matrixD _ajut((unsigned)G.phenoList.size(),(unsigned)G.phenoList.size());



                                    if (!phenosNeedReordering)
                                    {
                                        for (int i=0;i<G.phenoList.size();i++)
                                        {
                                            for (int j=i;j<G.phenoList.size();j++)
                                            {
                                                G.markerList[position].setVjk(i, j, G.markerList[position].getVjk(i,j) + atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));

                                                _ajut.put(i,j,atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));
                                                _ajut.put(j,i,atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));
                                                k++;
                                            }
                                        }
                                        for (int i=0;i<G.phenoList.size();i++)
                                        {
                                            for (int j=0;j<G.phenoList.size();j++)
                                            {
                                                double x1 = G.markerList[position].getSj(i);
                                                //changing double x2 = atof(tokens2[22+(i*2)].c_str()); to double x2 = atof(tokens2[22+(j*2)].c_str());
                                                double x2 = atof(tokens2[16+(j*2)].c_str());
                                                double x3 = _ajut.get(i, j);
                                                G.markerList[position].setSj(i,x1+(x2*x3));


                                            }
                                        }
                                    }
                                    else //we need to reorder phenos:(
                                    {
                                        for (int i=0;i<G.phenoList.size();i++)
                                        {
                                            for (int j=i;j<G.phenoList.size();j++)
                                            {
                                                int new_i, new_j;
                                                bool ok = false;
                                                for (int l=0;l<G.phenoList.size();l++){if (G.phenoList[i] == tokens3[l]){new_i=l;ok=true;}}
                                                if (!ok){cerr << "Non-matching phenos in file: " << myFile << endl;exit(1);}
                                                ok = false;
                                                for (int l=0;l<G.phenoList.size();l++){if (G.phenoList[j] == tokens3[l]){new_j=l;ok=true;}}
                                                if (!ok){cerr << "Non-matching phenos in file: " << myFile << endl;exit(1);}
                                                if (new_j < new_i){double tmp; tmp=new_j; new_j=new_i;new_i=tmp;}

 //                                               G.markerList[position].setVjk(new_i, new_j, G.markerList[position].getVjk(new_i,new_j) + atof(tokens2[22+(G.phenoList.size()*2)+k].c_str()));
                                                G.markerList[position].setVjk(new_i, new_j, G.markerList[position].getVjk(new_i,new_j) + atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));

                                                _ajut.put(new_i,new_j,atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));
                                                _ajut.put(new_j,new_i,atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));
                                                k++;
                                            }
                                        }
                                        for (int i=0;i<G.phenoList.size();i++)
                                        {
                                            for (int j=0;j<G.phenoList.size();j++)
                                            {
                                                int new_i, new_j;
                                                bool ok = false;
                                                for (int l=0;l<G.phenoList.size();l++){if (G.phenoList[i] == tokens3[l]){new_i=l;ok=true;}}
                                                if (!ok){cerr << "Non-matching phenos in file: " << myFile << endl;exit(1);}
                                                ok = false;
                                                for (int l=0;l<G.phenoList.size();l++){if (G.phenoList[j] == tokens3[l]){new_j=l;ok=true;}}
                                                if (!ok){cerr << "Non-matching phenos in file: " << myFile << endl;exit(1);}
                                                //if (new_j < new_i){double tmp; tmp=new_j; new_j=new_i;new_i=tmp;}

                                                double x1 = G.markerList[position].getSj(i);
                                                //changing double x2 = atof(tokens2[22+(i*2)].c_str()); to double x2 = atof(tokens2[22+(j*2)].c_str());
                                                double x2 = atof(tokens2[16+(new_j*2)].c_str());
                                                double x3 = _ajut.get(i, j);
                                                G.markerList[position].setSj(i,x1+(x2*x3));


                                            }
                                        }

                                    }
                                    G.markerList[position]._cohortCount++;
                                    G.markerList[position]._sampleCount+=sampleSize;

                                }
                                else
                                {
                                //present marker
                                    int position = G.markerPosition[currentMarker]-1;

                                    if (markerIsOK)
                                    {
                                        int k = 0;
                                        matrixD _ajut((unsigned)G.phenoList.size(),(unsigned)G.phenoList.size());


                                        if (!phenosNeedReordering)
                                        {

                                            for (int i=0;i<G.phenoList.size();i++)
                                            {
                                                for (int j=i;j<G.phenoList.size();j++)
                                                {
                                                    G.markerList[position].setVjk(i, j, G.markerList[position].getVjk(i,j) + atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));

                                                    _ajut.put(i,j,atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));
                                                    _ajut.put(j,i,atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));
                                                    k++;
                                                }
                                            }
                                            for (int i=0;i<G.phenoList.size();i++)
                                            {
                                                for (int j=0;j<G.phenoList.size();j++)
                                                {
                                                    double x;


                                                         x = G.markerList[position].getSj(i)+atof(tokens2[16+(j*2)].c_str())*_ajut.get(i, j);


                                                    G.markerList[position].setSj(i,x);

                                                }
                                            }
                                        }
                                        else //phenos need reordering:(
                                        {
                                            for (int i=0;i<G.phenoList.size();i++)
                                            {
                                                for (int j=i;j<G.phenoList.size();j++)
                                                {
                                                    int new_i, new_j;
                                                    bool ok = false;
                                                    for (int l=0;l<G.phenoList.size();l++){if (G.phenoList[i] == tokens3[l]){new_i=l;ok=true;}}
                                                    if (!ok){cerr << "Non-matching phenos in file: " << myFile << endl;exit(1);}
                                                    ok = false;
                                                    for (int l=0;l<G.phenoList.size();l++){if (G.phenoList[j] == tokens3[l]){new_j=l;ok=true;}}
                                                    if (!ok){cerr << "Non-matching phenos in file: " << myFile << endl;exit(1);}
                                                    if (new_j < new_i){double tmp; tmp=new_j; new_j=new_i;new_i=tmp;}
                                                    G.markerList[position].setVjk(new_i, new_j, G.markerList[position].getVjk(new_i,new_j) + atof(tokens2[16+(G.phenoList.size()*2)+k].c_str()));

                                                    _ajut.put(new_i,new_j,atof(tokens2[16+(G.phenoList.size()*2)+k].c_str())); //marika:changed to 16
                                                    _ajut.put(new_j,new_i,atof(tokens2[16+(G.phenoList.size()*2)+k].c_str())); //marika:changed to 16
                                                    k++;
                                                }
                                            }
                                            for (int i=0;i<G.phenoList.size();i++)
                                            {
                                                for (int j=0;j<G.phenoList.size();j++)
                                                {
                                                    double x;
                                                    int new_i, new_j;
                                                    bool ok = false;
                                                    for (int l=0;l<G.phenoList.size();l++){if (G.phenoList[i] == tokens3[l]){new_i=l;ok=true;}}
                                                    if (!ok){cerr << "Non-matching phenos in file: " << myFile << endl;exit(1);}
                                                    ok = false;
                                                    for (int l=0;l<G.phenoList.size();l++){if (G.phenoList[j] == tokens3[l]){new_j=l;ok=true;}}
                                                    if (!ok){cerr << "Non-matching phenos in file: " << myFile << endl;exit(1);}

                                                        x = G.markerList[position].getSj(i)+atof(tokens2[16+(new_j*2)].c_str())*_ajut.get(i, j);



                                                    G.markerList[position].setSj(i,x);

                                                }
                                            }


                                        }



                                        G.markerList[position]._cohortCount++;
                                        G.markerList[position]._sampleCount+=sampleSize;






                                    }
                                }
                                if (markerIsOK){markerPresent[currentMarker]=1;}//marker info has been read and it is present now
                            } //marker is not present yet
                        }//marker didnt pass QC or is present
                        else
                        {
                            if (markerNoDuplicate[tokens2[0]]==1){markerDupCount++;}
                            if (G.nFilter>atoi(tokens2[2].c_str())){markerbadNCount++;}
                            if (tokens2[10]=="NA"){markerbadPCount++;}
                        }

                    }
                    lineNr++;
                }
                fileNr++;

                cout << "Reading file done.\nOK markers: " << markerNoDupCount << endl;
                cout << "Small N: " << markerbadNCount <<  " Missing model: " << markerbadPCount<<endl;


            }
        }
    }
    else
    {cout << "Cannot read input file. Exit program!" << endl;exit(1);}



    return true;
}
