/********************************************************************
Stub file for assembly optimized ALGLIB subroutines.
********************************************************************/
#ifndef IALGLIB_H
#define IALGLIB_H

#include "ap.h"

#endif

