/*************************************************************************
 METAMARV software:  Sep, 2016

 Contributors:
 * Marika Kaakinen
 * Reedik M�gi
 * Krista Fischer
 * Andrew P Morris
 * Inga Prokopenko

Copyright (c) 2015, Imperial College London
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*************************************************************************/
#ifndef _TOOLS_H_
#define _TOOLS_H_

#include <iostream>
#include <map>
#include <vector>
#include <stdlib.h>
#include <fstream>
#include <math.h>
#include <cctype> // std::toupper
#include <string>
#include <algorithm>
using namespace std;

void sortVec(vector <double>& x, int size);

int Tokenize(const  string& str1,
                      vector<string>& tokens,
			const string& delimiters);
string uc(string s);	//uppercase
bool checkAlleles(string & s1, string & s2);	//check if alleles are ok and change numbers to letters if necessary
string flip(string s);	//flip the alleles if
vector <bool> phenoMasker(int, int);
const double nullLikelihood (const vector<double>& COPYpheno);
string  HWE(double aa, double aA, double AA);

class Marker
{
private:
    vector <double> _Vjk;
    vector <double> _Sj;
    string _ea;
    string _nea;
    int _phenoCount;

public:
    string _name;
    int _cohortCount;
    int _sampleCount;


    bool setVjk(int , int, double);
    double getVjk(int, int);
    bool setSj(int ,  double);
    double getSj(int);
    string getEa(){return _ea;}
    string getTransposedEa(){return flip(_ea);}
    bool setEa(string x){_ea = x;return true;}
    string getNea(){return _nea;}
    string getTransposedNea(){return flip(_nea);}
    bool setNea(string x){_nea = x;return true;}



    Marker(string, int);

};

#endif
